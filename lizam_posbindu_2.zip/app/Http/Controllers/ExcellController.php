<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ExcellController extends Controller
{
    public function index()
    {
        return view('excell.index');
    }

    public function rekap(Request $request)
    {
        $request->validate([
            'bulan' => 'required'
        ]);

        $data = DB::table('pemeriksaans')
            ->select('pemeriksaans.*', 'pasiens.nama_lengkap')
            ->join('pasiens', 'pasiens.id', '=', 'pemeriksaans.pasien_id')
            ->whereMonth('tanggal', '=', $request->bulan)
            ->get();
        
        if (empty($data[0])) {
            # jika data rekap kosong maka
            return redirect()->route('rekap')->with('galat', 'Data Pemeriksaan Tidak Ada');
        }
        
        // dd($data);
    }
}
