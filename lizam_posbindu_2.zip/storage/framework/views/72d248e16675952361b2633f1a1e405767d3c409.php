<!-- Sidebar Menu -->
<nav class="mt-2">
    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
        <!-- Add icons to the links using the  -->
        <?php if(auth()->user()->role == 'admin'): ?>
            
        <?php elseif(auth()->user()->role == 'kader'): ?>
            
            <li class="nav-item">
                <a href="<?php echo e(route('kader')); ?>" class="nav-link text-light <?php echo e(Route::is('kader') ? 'active' : ''); ?>">
                    <i class="nav-icon fas fa-home"></i>
                    <p>
                        Dashboard Kader
                    </p>
                </a>
            </li>

            <li class="nav-item">
                <a href="<?php echo e(route('kader.pasien')); ?>" class="nav-link text-light <?php echo e(Route::is('kader.pasien') ? 'active' : ''); ?>">
                    <i class="nav-icon fas fa-table"></i>
                    <p>
                        Pasien Management
                    </p>
                </a>
            </li>

            <li class="nav-item">
                <a href="<?php echo e(route('kader.periksa.pasien')); ?>" class="nav-link text-light <?php echo e(Request::segment(3) == 'periksa' ? 'active' : null); ?>">
                    <i class="nav-icon fas fa-table"></i>
                    <p>
                        Pemeriksaan Pasien
                    </p>
                </a>
            </li>

            <li class="nav-item">
                <a href="<?php echo e(route('rekap')); ?>" class="nav-link text-light <?php echo e(Request::segment(2) == 'rekap' ? 'active' : null); ?>">
                    <i class="nav-icon fas fa-file-excel"></i>
                    <p>
                        Rekap Pemeriksaan
                    </p>
                </a>
            </li>
        <?php endif; ?>

    </ul>
</nav>
<!-- /.sidebar-menu -->
<?php /**PATH C:\xampp\htdocs\lizam_posbindu_2\resources\views/layouts/admin/menu.blade.php ENDPATH**/ ?>