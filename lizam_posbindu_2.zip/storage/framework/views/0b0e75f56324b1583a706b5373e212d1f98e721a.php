

<?php $__env->startSection('title'); ?>
    Rekap Data Pasien <?php echo e($data->nama_lengkap); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1><?php echo $__env->yieldContent('title'); ?></h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('kader')); ?>">Kader</a></li>
                            <li class="breadcrumb-item active"><?php echo $__env->yieldContent('title'); ?></li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong><?php echo e($message); ?></strong>
                    </div>
                <?php endif; ?>
                <div class="card card-success">
                    <div class="card-header">
                        <h3 class="card-title">Pasien a.n <?php echo e($data->nama_lengkap); ?></h3>
                    </div>
                    <div class="card-body">
                        <table class="table">
                            <tbody>
                                <tr>
                                    <td>Nama Lengkap</td>
                                    <td>:</td>
                                    <td><?php echo e($data->nama_lengkap); ?></td>
                                    <td>Nama Panggilan</td>
                                    <td>:</td>
                                    <td><?php echo e($data->nama_panggilan); ?></td>
                                </tr>
                                <tr>
                                    <td>Nomor KTP</td>
                                    <td>:</td>
                                    <td><?php echo e($data->ktp); ?></td>
                                    <td>Tanggal Lahir</td>
                                    <td>:</td>
                                    <td><?php echo e($data->tanggal_lahir); ?></td>
                                </tr>
                                <tr>
                                    <td>Jenis Kelamin</td>
                                    <td>:</td>
                                    <td><?php echo e($data->jk); ?></td>
                                    <td>Golongan Darah</td>
                                    <td>:</td>
                                    <td><?php echo e($data->goldar); ?></td>
                                </tr>
                                <tr>
                                    <td>Agama</td>
                                    <td>:</td>
                                    <td><?php echo e($data->agama); ?></td>
                                    <td>Pekerjaan</td>
                                    <td>:</td>
                                    <td><?php echo e($data->pekerjaan); ?></td>
                                </tr>
                                <tr>
                                    <td>Nomor HP</td>
                                    <td>:</td>
                                    <td><?php echo e($data->no_hp); ?></td>
                                    <td>Pendidikan Terakhir</td>
                                    <td>:</td>
                                    <td><?php echo e($data->pendidikan); ?></td>
                                </tr>
                                <tr>
                                    <td>Email</td>
                                    <td>:</td>
                                    <td><?php echo e($data->email); ?></td>
                                    <td>Status</td>
                                    <td>:</td>
                                    <td><?php echo e($data->pernikahan); ?></td>
                                </tr>
                                <tr>
                                    <td colspan="1">Alamat Lengkap</td>
                                    <td>:</td>
                                    <td colspan="4"><?php echo e($data->alamat); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12">
                        <div class="card card-success">
                            <div class="card-header">
                                <div class="d-flex justify-content-between">
                                    <h3 class="card-title">Rekap Pemeriksaan</h3>
                                    <button class="btn btn-light btn-sm">Cetak PDF</button>
                                </div>
                            </div>
                            <div class="card-body">

                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Tanggal Pemeriksaan</th>
                                            <th scope="col">Sistol</th>
                                            <th scope="col">Diastol</th>
                                            <th scope="col">Tinggi</th>
                                            <th scope="col">Berat</th>
                                            <th scope="col">Lingkar</th>
                                            <th scope="col">Gula</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $riwayat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($loop->iteration); ?></th>
                                                <th><?php echo e($rk->tanggal); ?></th>
                                                <td><?php echo e($rk->sistol); ?></td>
                                                <td><?php echo e($rk->diastol); ?></td>
                                                <td><?php echo e($rk->tb); ?> cm</td>
                                                <td><?php echo e($rk->bb); ?> Kg</td>
                                                <td><?php echo e($rk->perut); ?> cm</td>
                                                <td><?php echo e($rk->gula); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- /.content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lizam_posbindu_2\resources\views/pasien/view.blade.php ENDPATH**/ ?>